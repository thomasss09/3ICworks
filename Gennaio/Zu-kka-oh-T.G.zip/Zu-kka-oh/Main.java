
public class Main {

    public static void main(String[] args) {
        Partita partita = new Partita("Pino", "Gino");
        partita.gioca();
    }
}
